﻿using System;
namespace PracticeExercise4
{
    public class EmptyQueueException: Exception
    {
        public EmptyQueueException()
        {
        }
    }
}
