﻿using System;
namespace PracticeExercise4
{
    public class EmptyStackException:Exception
    {
        public EmptyStackException()
        {
        }
    }
}
